import consts
from devices import Device

# tokens

class Button(object): pass
class Axis(object): pass
class Pad(object): pass

# device wrappers

class GameDevice(Device):
    """Basic gaming wrapper for Human Interface Devices.
    Simply filters out elements that aren't suitable for gaming.
    """
    def __init__(self, index_or_device):
        if isinstance(index_or_device, Device):
            index_or_device = index_or_device.index
        Device.__init__(self, index_or_device)
        self.elements = [ele for ele in self.elements if is_game_element(ele)]
        
    GameUsages = {
        consts.kHIDPage_GenericDesktop: 
            [consts.kHIDUsage_GD_X, consts.kHIDUsage_GD_Y, consts.kHIDUsage_GD_Z, 
                consts.kHIDUsage_GD_Rx, consts.kHIDUsage_GD_Ry, consts.kHIDUsage_GD_Rz,
                consts.kHIDUsage_GD_Slider, consts.kHIDUsage_GD_Dial, consts.kHIDUsage_GD_Wheel,
                consts.kHIDUsage_GD_Hatswitch, consts.kHIDUsage_GD_Start, consts.kHIDUsage_GD_Select,
                consts.kHIDUsage_GD_DPadUp, consts.kHIDUsage_GD_DPadDown, consts.kHIDUsage_GD_DPadLeft, consts.kHIDUsage_GD_DPadRight],
        consts.kHIDPage_Simulation: 
            [consts.kHIDUsage_Sim_Aileron, consts.kHIDUsage_Sim_AileronTrim, 
                consts.kHIDUsage_Sim_AntiTorqueControl, consts.kHIDUsage_Sim_AutopilotEnable, 
                consts.kHIDUsage_Sim_ChaffRelease, consts.kHIDUsage_Sim_CollectiveControl,
                consts.kHIDUsage_Sim_DiveBrake, consts.kHIDUsage_Sim_ElectronicCountermeasures, 
                consts.kHIDUsage_Sim_Elevator, consts.kHIDUsage_Sim_ElevatorTrim, 
                consts.kHIDUsage_Sim_Rudder, consts.kHIDUsage_Sim_Throttle, consts.kHIDUsage_Sim_FlightCommunications,
                consts.kHIDUsage_Sim_FlareRelease, consts.kHIDUsage_Sim_LandingGear, 
                consts.kHIDUsage_Sim_ToeBrake, consts.kHIDUsage_Sim_Trigger, 
                consts.kHIDUsage_Sim_WeaponsArm, consts.kHIDUsage_Sim_Weapons, 
                consts.kHIDUsage_Sim_WingFlaps, consts.kHIDUsage_Sim_Accelerator, 
                consts.kHIDUsage_Sim_Brake, consts.kHIDUsage_Sim_Clutch, consts.kHIDUsage_Sim_Shifter, 
                consts.kHIDUsage_Sim_Steering, consts.kHIDUsage_Sim_TurretDirection, 
                consts.kHIDUsage_Sim_BarrelElevation, consts.kHIDUsage_Sim_DivePlane, 
                consts.kHIDUsage_Sim_Ballast, consts.kHIDUsage_Sim_BicycleCrank,
                consts.kHIDUsage_Sim_HandleBars, consts.kHIDUsage_Sim_FrontBrake, 
                consts.kHIDUsage_Sim_RearBrake
            ],
        consts.kHIDPage_Game:
            [consts.kHIDUsage_Game_TurnRightOrLeft, consts.kHIDUsage_Game_PitchUpOrDown, 
                consts.kHIDUsage_Game_RollRightOrLeft, consts.kHIDUsage_Game_MoveRightOrLeft, 
                consts.kHIDUsage_Game_MoveForwardOrBackward, consts.kHIDUsage_Game_MoveUpOrDown,
                consts.kHIDUsage_Game_LeanRightOrLeft, consts.kHIDUsage_Game_LeanForwardOrBackward,
                consts.kHIDUsage_Game_HeightOfPOV, consts.kHIDUsage_Game_Flipper, consts.kHIDUsage_Game_SecondaryFlipper,
                consts.kHIDUsage_Game_Bump, consts.kHIDUsage_Game_NewGame, consts.kHIDUsage_Game_ShootBall
            ],
    }


class GamePad(GameDevice):
    """Higher-level gaming wrapper for HIDs
    Given a gaming-suitable HID, this provides higher-level facilities than the normal
    Device interface, splitting out axes, buttons and direction-pads into seperate lists.
    """
    def __init__(self, index_or_device):
        GameDevice.__init__(self, index_or_device)
        self.buttons = []
        self.axes = []
        self.pads = []
        sorter =  { Button: self.buttons, Axis: self.axes, Pad: self.pads}
        for ele in self.elements:
            sorter[guess_type(ele)].append(ele)


# transformation functions

def cutoff_deadzone(v, cutoff=0.1):
    """Deadzone transformation, cutoff style: Any value below the cutoff point is zeroed,
    otherwise the result is left intact."""
    if abs(v)<cutoff:
        return 0
    return v
cutoff_deadzone.range = (-1,1)


def smooth_deadzone(v, cutoff=0.1):
    """Deadzone transformation, smooth style: Any value below the cutoff point is zeroed,
    otherwise the result is rescaled smoothly. This is recommended over cutoff_deadzone
    for most uses as it allows small movements to be made."""
    if v>cutoff:
        return (v-cutoff) * (1.0/(1.0-cutoff))
    elif v<-cutoff:
        return (v+cutoff) * (1.0/(1.0-cutoff))
    else:
        return 0
smooth_deadzone.range = (-1,1)


# miscellaneous useful functions

def guess_type(ele):
    """Returns whether a device is believed to be a button, an axis, or a direction pad,
    largely based on guesswork. Result is one of three symbolic constants defined by
    the module, Button, Axis or Pad."""
    if (ele.min==0 and ele.max==1) or ele.usagepage==consts.kHIDPage_Button:
        return Button
    elif (ele.usagepage==consts.kHIDPage_GenericDesktop) and (ele.usage==consts.kHIDUsage_GD_Hatswitch):
        return Pad
    return Axis;
    
def is_game_element(ele):
    """Returns whether a specific element on a device is considered to be used for gaming,
    largely based on guesswork."""
    if ele.usagepage==consts.kHIDPage_Button: return True
    try:
        uses = GameDevice.GameUsages[ele.usagepage]
        return ele.usage in uses
    except:
        return False

def is_probably_game_device(device):
    """Returns whether a device is likely to be used on gaming. Specifically (hackishly)
    excludes laptop trackpads which would otherwise show up in the list and confuse 
    people and software alike."""
    if 'Trackpad' in device.name: # :-P
        return False
    for ele in device.elements:
        if is_game_element(ele):
            return True
    return False

