from ..devices import Device

class K8055(Device):
    digital_map = [16,32,1,64,128]
    def __init__(self, index_or_device):
        if isinstance(index_or_device, Device):
            index_or_device = index_or_device.index
        Device.__init__(self, index_or_device)
        self.digital_in = self.elements[1]
        self.analogue_in = [self.elements[3], self.elements[4]]
        self.counter = [self.elements[5], self.elements[7]]
        self.elements[9].write(5) # set 9 to 5; what a way to make a living. [output doesn't work if you don't]
        self.digital_out = self.elements[10]
        self.analogue_out = [self.elements[11], self.elements[12]]
        
    def read_digit(self, i):
        return 1 if self.digital_in.read() & self.digital_map[i] else 0
        
    @staticmethod
    def find(devs):
        for dev in devs:
            if dev.manufacturer.startswith('Velleman') and '8055' in dev.name:
                return dev
        
