#!/usr/bin/env python

def build_tables():
    import consts

    # Unfortunately, the usage constants are not cleanly/regularly laid out.
    # We need to hack in some filtering to split them into the right categories.
    hacks = [
        ("GenericDesktop", "GD_"),
        ("Simulation", "Sim_"),
        ("VR", "VR_"),
        ("Sport", "Sprt_"),
        ("Game", "Game_"),
        ("KeyboardOrKeypad", "Keyboard"),
        ("KeyboardOrKeypad", "Keypad"),
        ("LEDs", "LED_"),
        ("Button", "Button_"),
        ("Ordinal", "Ord_"),
        ("Telephony", "Tfon_"),
        ("Consumer", "Csmr_"),
        ("Digitizer", "Dig_"),
        ("PID", "PID_"),
        # ("Unicode", ""),
        ("AlphanumericDisplay", "AD_"),
        ("PowerDevice", "PD_"),
        ("BatterySystem", "BS_"),
        # ("BarCodeScanner", ""),
        # ("Scale", ""),
        # ("CameraControl", ""),
        # ("Arcade", ""),
    ]
    tables = {}
    lookup = {}
    for constant in [key for key in dir(consts) if key.startswith('k')]:
        cons = constant[1:] # hack off leading k
        tablename, token = cons.split('_',1)
    
        if not tablename.startswith('HIDPage'):
            for subtable, start in hacks:
                if token.startswith(start):
                    tablename=subtable
                    if start!='Keypad':
                        token=token[len(start):]                        
                    break
    
        table = tables.setdefault(tablename, {})
        table[token] = getattr(consts, constant)
        
    for table, data in tables.items():
        lookup[table] = d = {}
        for key, value in data.items():
            d[value]=key

    global UsagePageNumbers, UsagePageNames
    global UsageNames, UsageNumbers

    UsagePageNumbers = tables['HIDPage']
    UsagePageNames = lookup['HIDPage']
    UsageNames = {}
    UsageNumbers = {}
    for name in UsagePageNumbers: # naming proves confusing here :P
        if name in lookup:
            UsageNames[name] = lookup[name]
            UsageNumbers[name] = tables[name]


build_tables()
del build_tables
