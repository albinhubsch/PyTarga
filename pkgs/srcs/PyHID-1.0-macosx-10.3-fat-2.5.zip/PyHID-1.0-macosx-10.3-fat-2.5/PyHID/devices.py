import lowlevel, consts, usage

class Element(object):
    """Represents one element on a device, generally, one measurement or setting.
    For instance, a button, an LED, _one_ axis of a joystick."""

    was_pressed=False
    
    def __init__(self, device, index):
        self.device = device
        self.index = index
        self.usage = lowlevel.get_element_usage(self.device.index, self.index)
        self.usagepage = lowlevel.get_element_usage_page(self.device.index, self.index)
        self.min = lowlevel.get_element_value_min(self.device.index, self.index)
        self.max = lowlevel.get_element_value_max(self.device.index, self.index)
        self.set_transform(0.0, 1.0, None)
        
    def __repr__(self):
        return "<Element %d (%s %s) of %s>" % (self.index, self.get_usage_string(), self.get_usage_page_string(), self.device)
        
    def read(self):
        """Return the raw value of the element."""
        return lowlevel.get_element_value(self.device.index, self.index)
        
    def write(self, value):
        """Set the raw value of the element."""
        lowlevel.set_element_value(self.device.index, self.index, value)
        
    def enable_monitoring(self):
        """Add this element to the set of elements monitored by the event queue."""
        self.device.enable_monitoring()
        lowlevel.start_monitoring_element(self.device.index, self.index)

    def disable_monitoring(self):
        """Remove this element from the set of elements monitored by the event queue."""
        lowlevel.stop_monitoring_element(self.device.index, self.index)
        
    def get_usage_string(self):
        """Return a human-readable string representing the expected usage of the element."""
        return usage.UsageNames.get(self.get_usage_page_string(),{}).get(self.usage,'<Unknown: 0x%x>' % self.usage)

    def get_usage_page_string(self):
        """Return a human-readable string of the usage page (broad category) of the element."""
        return usage.UsagePageNames.get(self.usagepage,'<Unknown: 0x%x>' % self.usagepage)
        
    def _with_transform(self):
        # lowlevel has transformed into range suitable for transform_func, then we apply
        # client-requested transform ourselves on the way out:
        return self.range[0] + (self.transform_func(lowlevel.get_element_value_normalised(self.device.index, self.index))-self.offset) * self.range[1]

    def _without_transform(self):
        # no transforms applied; the range has already been set in the lowlevel layer.
        return lowlevel.get_element_value_normalised(self.device.index, self.index)
        
    def __call__(self):
        """Return the cooked value of the element."""
        return self.read_transformed()
        
    def debounced_press(self):
        """For button elements, return whether the button has just been pressed.
        In other words, once debounced_press() returns True for the first time, it
        won't return True again until the button has been released and then re-pressed."""
        current = self.read() > ((self.max-self.min)*0.5)
        result = current and not self.was_pressed
        self.was_pressed = current
        return result        
        
    def set_transform(self, new_min=None, new_max=None, transform_func=None):
        """Set the transformation applied to the raw element value in order to cook it.
        You can provide replacement minimum and maximum values, plus an optional function
        to transform the value in arbitrary ways."""
        if new_min is None:
            new_min = self.min
        if new_max is None:
            new_max = self.max            
        self.range = (new_min, new_max-new_min)        
        self.transform_func = transform_func
        if transform_func:
            if hasattr(transform_func, "range"):
                func_min, func_max = transform_func.range
                lowlevel.set_element_normalisation_range(self.device.index, self.index, func_min, func_max)
                self.range = self.range[0], self.range[1]/(func_max-func_min)
                self.offset = func_min
                self.func_range = func_max-func_min
            else:
                lowlevel.set_element_normalisation_range(self.device.index, self.index, 0, 1)
                self.func_range = 0, 1
            self.read_transformed = self._with_transform
        else:
            lowlevel.set_element_normalisation_range(self.device.index, self.index, new_min, new_max)
            self.read_transformed = self._without_transform
            

class Device(object):
    """Represents one Human Interface Device plugged into the system."""
    def __init__(self, index):
        self.index = index
        self.name = lowlevel.get_device_name(index)
        self.classname = lowlevel.get_device_class_name(index)
        self.manufacturer = lowlevel.get_device_manufacturer(index)
        self.elements = [Element(self, i) for i in range(lowlevel.get_device_element_count(self.index))]
        self.raw_elements = self.elements
        
    def enable_monitoring(self):
        """Enable the event queue for this device."""
        lowlevel.enable_monitoring(self.index)

    def disable_monitoring(self):
        """Disable the event queue for this device."""
        lowlevel.disable_monitoring(self.index)
        
    def poll(self):
        """Check the event queue for this device, pulling out the first event and
        returning the (element, value, time), or None if the queue is empty."""
        event = lowlevel.poll_device(self.index)
        if event:
            ele_idx, value, time = event
            return element, value, time


def scan_devices():
    """Rescan the system for attached devices, and return a list of every one found.
    Note: Depending on what unplugging and re-attaching the user is doing, devices
    can 'move around' in the list as a result."""
    lowlevel.rescan_devices()
    return [Device(i) for i in range(lowlevel.get_device_count())]
    
